package com.example.devarchive.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BugEntryRequest {
    @NotBlank(message = "Error text cannot be empty")
    private String errorText;

    @NotBlank(message = "Solution text cannot be empty")
    private String solutionText;

    @NotBlank(message = "Programming language cannot be empty")
    private String programmingLanguage;

    private String errorStackTrace;

    private String tags;

    private String topic;
}
